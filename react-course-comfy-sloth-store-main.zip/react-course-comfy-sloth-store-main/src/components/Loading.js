import React from 'react'

const Loading = () => {
  return (
    <div className='section secton-center'>
      <div className='loading'></div>
    </div>
  )
}

export default Loading
